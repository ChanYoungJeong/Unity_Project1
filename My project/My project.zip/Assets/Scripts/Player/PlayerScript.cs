using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using System;

public class PlayerScript : MonoBehaviour
{
    public GameObject playerIdle;
    public GameObject playerAttack;

    public float maxHp;
    public float nowHp;
    public bool attacked;
    public float atkDmg;
    public float atkSpeed;
    public int critical;



    private void Start()
    {
        atkDmg = 10f;
        attacked = true;
        maxHp = 100f;
        nowHp = 100f;
        atkSpeed = 1.0f;
        critical = 1;


    }

    public void PlayerIdle()
    {
        playerIdle.SetActive(true);
        playerAttack.SetActive(false);
    }

    public void PlayerAttack()
    {
        playerIdle.SetActive(false);
        playerAttack.SetActive(true);
    }

}
