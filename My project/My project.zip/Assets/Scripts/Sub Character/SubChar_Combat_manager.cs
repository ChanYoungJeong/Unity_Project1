using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubChar_Combat_manager : MonoBehaviour
{
   /*
    Sub_CharStats Sub_Char_Status;
    Monster_Script Monster_Status;


    void Start()
    {
        Sub_Char_Status = transform.GetComponentInParent<Sub_CharStats>();
    }
    void Update()
    {
        
    }

    IEnumerator Basic_Attack(GameObject Monster)
    {
        Monster_Status = Monster.GetComponent<Monster_Script>();
        Monster_Status.nowHp -= Sub_Char_Status.attack;
        if (Monster_Status.nowHp <= 0)
        {
            Monster_Status.nowHp = 0;
            Destroy(Monster);
        }
        Debug.Log(Monster_Status.nowHp);
        yield return new WaitForSeconds(Sub_Char_Status.atkSpeed);
    }

    IEnumerator Attack_Duration()
    {
        yield return new WaitForSeconds(Sub_Char_Status.atkSpeed);
    }
 */
}