using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Monster_Script : MonoBehaviour
{
    // Start is called before the first frame update

    public string monsterType;
    public float maxHp;
    public float nowHp;
    public float atkDmg;
    public float atkSpeed;
    public int Golds;
    public int Exp;


}
